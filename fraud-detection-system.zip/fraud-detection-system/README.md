# Fraud Detection System (Flask + SQLite)

A college-project demonstration of a rule-based transaction risk checker. It provides dashboard statistics, history stored in SQLite and Chart.js analytics.

## Setup

1. Install Python 3.10 or newer.
2. Open the project folder in VS Code.
3. Create and activate a virtual environment (recommended):

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
# macOS/Linux
source .venv/bin/activate
```

4. Install Flask:

```bash
pip install -r requirements.txt
```

5. Start the application:

```bash
python app.py
```

6. Visit http://127.0.0.1:5000 in a browser.

## Rules

- Amount > ₹50,000: suspicious.
- More than 5 transactions/minute: fraud.
- Login country differs from transaction country: suspicious.
- Account less than 7 days old and amount > ₹20,000: fraud.

## Important

This is an academic rule-based demonstration. Labels are not proof of fraud and must be reviewed by a qualified person before any account decision. The local SQLite database (`fraud_detection.db`) is created automatically on first run. Delete it only if you want to clear the test history.
